/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.studentmanagementsystem;

/**
 *
 * @author Ali Shan
 */

public class Department {    
    private String dep_name;
    private String dephead_name;
    
    public Department(String dep_name, String dephead_name){
        this.dep_name = dep_name;
        this.dephead_name = dephead_name;
    }
    
    public Department(Department duplicate){
        this.dep_name = duplicate.dep_name;
        this.dephead_name = duplicate.dephead_name;
    }
    
    public void sHOW(){
        System.out.println("Department name: "+dep_name);
        System.out.println("Department head name: "+dephead_name);
    }
    
    public static void main(String[]args){
        Department d1 = new Department("COMPUTER SCIENCE","Maam Tahira");
        
        Department d2 = new Department(d1);
        
        System.out.println("----- Department Details -----");
        d1.sHOW();
        d2.sHOW();
    }
}
