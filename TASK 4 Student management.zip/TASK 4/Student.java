/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.studentmanagementsystem;

/**
 *
 * @author Ali Shan
 */
import java.util.Scanner;
public class Student {
    String name;
    String department;
    int roll_no;
    
    void aDD(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter name: ");
        name = sc.nextLine();
        
        System.out.print("Enter department name: ");
        department = sc.nextLine();
        
        System.out.print("Enter roll number: ");
        roll_no = sc.nextInt();
    }
    public void dISPLAY(){
        System.out.println("Name: "+this.name);
        System.out.println("Roll number: "+this.roll_no);
        System.out.println("Department: "+this.department);
    }
    
    public static void main(String[]args){
        Student s1 = new Student();
        System.out.println("Fill the details of 1st student.");
        s1.aDD();
        
        Student s2 = new Student();
        System.out.println("Fill the details of 2nd student.");
        s2.aDD();
        
        System.out.println("----- Student Details -----");
        s1.dISPLAY();
        s2.dISPLAY();
}
}
