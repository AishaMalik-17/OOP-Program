/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.task1;
import java.util.Scanner;
class Dish{
    String type;
    String ingredients;
    String cuisine;
}
/**
 *
 * @author Ali Shan
 */
public class Dishes{
    public static void main(String[] args) {
        Dish dish = new Dish();
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the type of dish (e.g., sweets, savory): ");
        dish.type = sc.nextLine();

        System.out.print("Enter the ingredients of the dish: ");
        dish.ingredients = sc.nextLine();

        System.out.print("Enter the cuisine of the dish (e.g., Asian, Italian, etc.): ");
        dish.cuisine = sc.nextLine();
        
        System.out.println("Welcome to the Asian Restaurant");
        System.out.println("Your selected choice of Dish is: " + dish.type);
        System.out.println("Your Dish contains the following ingredients: " + dish.ingredients);
        System.out.println("Your dish belongs to the " + dish.cuisine + " cuisine.");

    }
}

