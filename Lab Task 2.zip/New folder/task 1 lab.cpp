#include<iostream>
using namespace std;
void miles(){
	double result,km,m=0.621;
	cout<<"Enter distance in kilometer: ";
	cin>>km;
	result = km*m;
	cout<<km<<" is equal to "<<result<<" miles.";
}

void temp(){
	float cel,fah;
	cout<<"Enter temperature in celsius: ";
	cin>>cel;
	fah = (cel*9/5)+32;
	cout<<cel<<" Celsius in equal to "<<fah<<" Fahrenheit";
}

void time(){
	int second,sec,hours,min;
	cout<<"Enter time in sceonds: ";
	cin>>sec;
	hours = sec/3600;
	min = (sec%3600)/60;
	second= sec%60;
	cout<<"Time is "<<hours<<" hours "<<min<<" minutes and "<<second<<" seconds";
}
int main(){
	int choice;
	cout<<"----MENU----"<<endl;
	cout<<"Choose from the following service: "<<endl;
	cout<<"1. Convert kilometer in miles"<<endl;
	cout<<"2. Convert Celsius to Fahrenheit"<<endl;
	cout<<"3. Convert Seconds into Hours, Minutes & Seconds"<<endl;
	cin>>choice;
	
	switch(choice){
		
		case 1:
			miles();
			break;
		
		case 2:
		    temp();
			break;
			
		case 3:
		    time();
			break;	
		
		default:
			cout<<"Ivalid!!!Choose correct service";
			}
		return 0;	
}
