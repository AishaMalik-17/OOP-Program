#include <iostream>
#include <string>
using namespace std;

struct Employee {
 string name;
 float salary;
 int age;
 char gender;
 
};

void InputEmployeeData(Employee employees[],int count){
	for (int i=0;i<count;i++){
		cout<<"\nEnter details for employee "<<i+1<<" :"<<endl;
		cin.ignore();
		cout<<"Enter name: ";
		getline(cin,employees[i].name);
		cout<<"Enter salary: ";
		cin>>employees[i].salary;
		cout<<"Enter age: ";
		cin>>employees[i].age;
		cout<<"Enter gender: ";
		cin>>employees[i].gender;
	}
}

void DisplayEmployeeData(Employee employees[],int count){
	cout<<"\n----Record----"<<endl;
	for (int i=0;i<count;i++){
		cout<<"Name: " <<employees[i].name<<endl;
        cout<<"Salary: " <<employees[i].salary<<endl;
        cout<<"Age: " <<employees[i].age<<endl;
        cout<<"Gender: "<<employees[i].gender<<endl;
	}
}

void FindHighestSalary(Employee employees[],int count){
	int top= 0;
    for (int i=1; i<count;i++) {
        if (employees[i].salary>employees[top].salary) {
            top=i;
        }
   } 
    cout<<"\n----Employees with highest salary----"<<endl;
	cout<<"Name: " <<employees[top].name<<endl;
    cout<<"Salary: " <<employees[top].salary<<endl;
    cout<<"Age: " <<employees[top].age<<endl;
    cout<<"Gender: "<<employees[top].gender<<endl;
}

int main() {
 int num;
 cout << "Enter the number of employees: ";
 cin >> num;
 Employee employees[num]; 
 InputEmployeeData(employees,num);
 DisplayEmployeeData(employees,num);
 FindHighestSalary(employees,num);
 
 return 0;
}