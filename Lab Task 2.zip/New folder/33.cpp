#include <iostream>
using namespace std;
double calculateGrossSalary(double basicSalary, double allowancePercentage) {
    double allow = allowancePercentage/100; 
	float allowance  = basicSalary* allow;
    return basicSalary + allowance;
}

double calculateNetSalary(double grossSalary, double deductionPercentage) {
    float deduct  = deductionPercentage/100;
	double deduction = grossSalary*deduct;
    return grossSalary - deduction;
}

int main() {
    double basicSalary, allowancePercentage, deductionPercentage;
    cout << "Enter basic salary: ";
    cin >> basicSalary;

    cout << "Enter allowance percentage: ";
    cin >> allowancePercentage;

    cout << "Enter deduction percentage: ";
    cin >> deductionPercentage;

    double grossSalary = calculateGrossSalary(basicSalary, allowancePercentage);

    double netSalary = calculateNetSalary(grossSalary, deductionPercentage);

    cout << "Net Salary: " << netSalary << endl;

    return 0;
}