/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab_8task_3;

/**
 *
 * @author Ali Shan
 */
public class Course {
    String courseCode;
    String courseName;
    
    Course(String code, String name){
        
        this.courseCode = code;
        this.courseName = name;
    }
    
    void displayCourse(){
        System.out.println("Couse Code: "+courseCode);
        System.out.println("Course Name: "+courseName);
    }
}
