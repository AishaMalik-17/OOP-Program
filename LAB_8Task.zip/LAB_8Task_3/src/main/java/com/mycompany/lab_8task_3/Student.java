/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab_8task_3;

/**
 *
 * @author Ali Shan
 */
import java.util.ArrayList;
public class Student {
    String name;
    int studentID;
    ArrayList<Course>course;
    
    Student(int id, String name){
        this.studentID = id;
        this.name = name;
        course = new ArrayList<Course>();
    }
    
    void displayStudent(){
        System.out.println("Studnet id: "+studentID);
        System.out.println("Student name: "+name);
    }
    
    void enrollCourse(Course c){
        
        course.add(c);
    }
    
    void displayEnrolledCourses(){
        
        System.out.println(" ----- Enrolled Courses -----");
        for(Course courses : course){
            courses.displayCourse();
        }
    }
}
