/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lab_8task_3;

/**
 *
 * @author Ali Shan
 */
public class LAB_8Task_3 {

    public static void main(String[] args) {
        
        Course course1 = new Course("CS-1010","Programming Fundamnetal");
        Course course2 = new Course("CS-1082","Fundamnetal English");
        Course course3 = new Course("CS-2898","Object Oriented Programming");
        Course course4 = new Course("CS-2018","Digital Lab Design");
        
        Student student1 = new Student(62853,"Ayesha Malik");
        Student student2 = new Student(65449,"Rahema Shafique");
        Student student3 = new Student(60829,"Noor Fatima");
        
        student1.enrollCourse(course3);
        student1.enrollCourse(course4);
        
        student3.enrollCourse(course1);
        
        student2.enrollCourse(course4);
        student3.enrollCourse(course2);
        
        System.out.println(" \n----- Studnet 1 Details -----");
        student1.displayStudent();
        student1.displayEnrolledCourses();
        
        System.out.println(" \n----- Studnet 2 Details -----");
        student2.displayStudent();
        student2.displayEnrolledCourses();
        
        System.out.println(" \n----- Studnet 3 Details -----");
        student3.displayStudent();
        student3.displayEnrolledCourses();
    }
}
