/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab_8task_2;

/**
 *
 * @author Ali Shan
 */
public class Book {
    int bookID;
    String title;
    String author;
    
    Book(int id, String title, String author){
        this.bookID = id;
        this.title = title;
        this.author = author;
    }
    
    void displayBook(){
        
        System.out.println("Book ID: "+bookID);
        System.out.println("Title: "+title);
        System.out.println("Author: "+author);
    }
}
