/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lab_8task_2;

/**
 *
 * @author Ali Shan
 */
public class LAB_8Task_2 {

    public static void main(String[] args) {
        
        Book book1 = new Book(001, "How to boil water", "Donald Trump\n");
        Book book2 = new Book(002, "It ends with us", "Allan\n");
        Book book3 = new Book(003,"Ideology and constitution of pakistan", "Maria\n");
        Book book4 = new Book(004,"Children Story book","Me\n");
        
        Library lb = new Library();
        
        lb.addBook(book1);
        lb.addBook(book2);
        lb.addBook(book3);
        lb.addBook(book4);
        
        System.out.println(" ----- All Books -----");
        lb.displayAllBooks();
        
    
        System.out.println("----- After Removing Book -----");
        lb.removeBook(002);
        lb.displayAllBooks();
    }
}
