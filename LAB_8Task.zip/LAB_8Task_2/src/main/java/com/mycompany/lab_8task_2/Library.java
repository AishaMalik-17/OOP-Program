/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab_8task_2;

/**
 *
 * @author Ali Shan
 */

import java.util.ArrayList;
public class Library {
    
    ArrayList<Book>books;
    
    Library(){
    
        books = new ArrayList<Book>();
    }
    
    void addBook(Book book){
        books.add(book);
    }
    
    void removeBook(int bookID){
        
        for(int i=0;i<books.size();i ++){
            if(books.get(i).bookID == bookID){
                books.remove(i);
                System.out.println("The book has been removed.");
                return;
            }
        }
        System.out.println("Book not found.");
    }
    
    void displayAllBooks(){
        for(Book book : books){
            book.displayBook();
        }
    }
}
