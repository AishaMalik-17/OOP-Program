/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lab_8task_1;

/**
 *
 * @author Ali Shan
 */
public class LAB_8Task_1 {

    public static void main(String[] args) {
        System.out.println("----- Saving Account -----");
        SavingsAccount saving = new SavingsAccount(10.5,"123 2759 6395",50000.00);
        saving.displayDetails();
        saving.calculate();
        
        System.out.println("\n----- Current Account -----");
        CurrentAccount current =  new CurrentAccount(20000.00, "923 2759 6395", 100000.00);
        current.displayDetails();
        
        System.out.println("\n----- Fixed Deposit Account -----");
        FixedDepositAccount fixed =  new FixedDepositAccount(5, "839 2759 38738", 100000.00);
        fixed.displayDetails();
    }
}
