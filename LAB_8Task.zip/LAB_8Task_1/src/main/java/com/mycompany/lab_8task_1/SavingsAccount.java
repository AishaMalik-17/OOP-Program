/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab_8task_1;

/**
 *
 * @author Ali Shan
 */
public class SavingsAccount extends Account{
   
    double interestRate;
    
    SavingsAccount(double rate, String no, double bal){
        super(no,bal);
        this.interestRate = rate;
    }
    
    void calculate(){
        double interest = balance * interestRate/100;
        balance+=interest;
        System.out.println("Interest rate added: "+interest);
        System.out.println("New balance: "+balance);
    }
}
