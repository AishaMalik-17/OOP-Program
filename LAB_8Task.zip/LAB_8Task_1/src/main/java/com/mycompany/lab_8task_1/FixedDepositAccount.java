/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab_8task_1;

/**
 *
 * @author Ali Shan
 */
public class FixedDepositAccount extends Account{
    
    int maturityPeriod;
    
    FixedDepositAccount(int period, String no, double bal){
        
        super(no,bal);
        this.maturityPeriod = period;
    }
    
    @Override
    void displayDetails(){
        super.displayDetails();
        System.out.println("Maturity Period: "+maturityPeriod);
    }
}
