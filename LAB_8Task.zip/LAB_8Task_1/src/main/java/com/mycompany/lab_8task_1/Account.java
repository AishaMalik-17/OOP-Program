/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab_8task_1;

/**
 *
 * @author Ali Shan
 */
public class Account {
 
    String account_no;
    double balance;
    
    Account(String no, double bal){
        this.account_no = no;
        this.balance = bal;
    }
    
    void displayDetails(){
        System.out.println("Account number: "+account_no);
        System.out.println("Balance: "+balance);
    }

}
