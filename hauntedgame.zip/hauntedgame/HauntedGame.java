/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.hauntedgame;

/**
 *
 * @author Ali Shan
 */
import java.util.Scanner;
public class HauntedGame {

    public static void main(String[] args) {
       String guess;
       Scanner sc = new Scanner(System.in);
       String[] words = {"Ghost","Vampire","Zombie"};
       System.out.println("Welcome to the Haunted House Escape");
       System.out.println("Solve the mystery words to escape____");
       
       int score = 0;
       for(int i=0;i<3;i++){
           System.out.println("\nRoom "+(i+1) + ": Guess the mystery word.");
           
           boolean equal = false;
           do{
               System.out.println("Hint: The word has "+words[i].length()+" letters.\nAnd the first letter of word is "+words[i].charAt(0));
               System.out.print("Your guess: ");
               guess = sc.nextLine();
               
               if(guess.equalsIgnoreCase(words[i])){
                   System.out.println("Correct! Moving to the next room ....");
                   score+=1;
                   equal = true;
               }
               else{
                   System.out.println("Try Again.....\n");
                }
           }
           while(!equal);
          
       }
       System.out.println("\nGame Over! Your score is : "+score+"/3");
       System.out.println("Congratulations! You escaped the Haunted House!");
    }
}
