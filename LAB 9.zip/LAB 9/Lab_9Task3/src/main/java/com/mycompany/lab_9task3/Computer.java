/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab_9task3;

/**
 *
 * @author Ali Shan
 */
public class Computer {
    String brand;
    Processor processor;
    RAM ram;
    boolean isRunning;

    public Computer(String brand, String processorModel, double processorSpeedInGHz, int processorNumberOfCores, int ramCapacityInGB, int ramSpeedInMHz) {
        this.brand = brand;
        this.processor = new Processor(processorModel, processorSpeedInGHz, processorNumberOfCores);
        this.ram = new RAM(ramCapacityInGB, ramSpeedInMHz);
        this.isRunning = false;
    }

    void startComputer() {
        isRunning = true;
        System.out.println("Computer started.");
    }

    void shutdownComputer() {
        isRunning = false;
        System.out.println("Computer shutdown.");
    }

    void displayComputerSpecs() {
        System.out.println("Computer Brand: " + brand);
        processor.displayProcessorSpecs();
        ram.displayRAMSpecs();
        System.out.println("\nComputer Status: " + (isRunning ? "Running" : "Not Running"));
    }
    
}
