/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab_9task3;

/**
 *
 * @author Ali Shan
 */
public class Processor {
    String model;
    double speedInGHz;
    int numberOfCores;

    public Processor(String model, double speedInGHz, int numberOfCores) {
        this.model = model;
        this.speedInGHz = speedInGHz;
        this.numberOfCores = numberOfCores;
    }

    void displayProcessorSpecs() {
        System.out.println("\nProcessor Model: " + model);
        System.out.println("Processor Speed: " + speedInGHz + " GHz");
        System.out.println("Number of Cores: " + numberOfCores);
    }
}
