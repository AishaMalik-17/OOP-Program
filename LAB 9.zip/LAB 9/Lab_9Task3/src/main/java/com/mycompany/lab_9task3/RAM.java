/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab_9task3;

/**
 *
 * @author Ali Shan
 */
public class RAM {
     int capacityInGB;
    int speedInMHz;

    public RAM(int capacityInGB, int speedInMHz) {
        this.capacityInGB = capacityInGB;
        this.speedInMHz = speedInMHz;
    }

    void displayRAMSpecs() {
        System.out.println("\nRAM Capacity: " + capacityInGB + " GB");
        System.out.println("RAM Speed: " + speedInMHz + " MHz");
    }  
}
