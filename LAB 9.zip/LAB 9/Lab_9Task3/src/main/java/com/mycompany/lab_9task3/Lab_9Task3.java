/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lab_9task3;

/**
 *
 * @author Ali Shan
 */
public class Lab_9Task3 {

    public static void main(String[] args) {
        Computer computer = new Computer("Dell", "Intel Core i7", 3.2, 8, 16, 3200);
        
        computer.displayComputerSpecs();
        computer.startComputer();
        computer.displayComputerSpecs();
        computer.shutdownComputer();
        computer.displayComputerSpecs();
    }
}
