/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab_9task_2;

/**
 *
 * @author Ali Shan
 */
import java.util.ArrayList;
public class Course {
    
    String title;
    String code;
    
    ArrayList<Student> students;
    
    Course(String title, String code){
        
        this.title = title;
        this.code = code;
        
        this.students = new ArrayList<>();
    }
    
    void addStudent(Student S){
        
        students.add(S);
    }
    
    void removeStudent(Student S){
        
            if(students.remove(S)){
                System.out.println(S.name+" has been removed");
            }
            else{
                System.out.println("Student not found");
            }
    }
    
    void diplay(){
        
        System.out.println("\nCourse title: " + title);
        System.out.println("Course code: " + code);
        for (Student stu : students) {
            stu.displayDetails();
        }
    }
}
