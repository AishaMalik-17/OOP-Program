/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab_9task_2;

/**
 *
 * @author Ali Shan
 */
public class Student {
    String name;
    String email;
    int Sid;
    
    Student(String n, String email, int id){
        
        this.name = n;
        this.email = email;
        this.Sid = id;
    
    }
    
    void displayDetails(){
        
        System.out.println("\nName: "+name);
        System.out.println("Student id: "+Sid);
        System.out.println("Email id: "+email);
    }
    
    void submit(){
        
        System.out.println(name+" Assignment has been submitted.");
    } 
}
