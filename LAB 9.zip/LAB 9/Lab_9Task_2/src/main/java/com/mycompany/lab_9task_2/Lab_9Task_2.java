/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lab_9task_2;

/**
 *
 * @author Ali Shan
 */
public class Lab_9Task_2 {

    public static void main(String[] args) {
        
        Student s1 = new Student("Ayesha","aisha@gamil.com", 121);
        Student s2 =  new Student("Zaraa","zaara@gamil.com", 11);
        
        Course c1 = new Course("Pre calculus", "10B42");
        
        c1.addStudent(s1);
        c1.addStudent(s2);
        
        c1.diplay();
        System.out.println();
        s1.submit();
        s2.submit();
        
        c1.removeStudent(s1);
    }
}
