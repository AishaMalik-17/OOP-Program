/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask_9;

/**
 *
 * @author Ali Shan
 */
import java.util.ArrayList;

public class Hospital {
    String name;
    String location;
    ArrayList<Doctor> doctors;
    
    Hospital(String n, String l){
        
        this.name = n;
        this.location = l;
        
        this.doctors = new ArrayList<>();
    }
    
    void addDoctor(Doctor d){
        
        doctors.add(d);
    }
    
    void display(){
        
        System.out.println("\nHospital Name: " + name);
        System.out.println("Location: " + location);
        for (Doctor doctor : doctors) {
            doctor.showDoctorInfo();
        }
    }
    }
    

