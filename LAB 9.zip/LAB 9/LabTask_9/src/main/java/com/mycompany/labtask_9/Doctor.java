/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.labtask_9;

/**
 *
 * @author Ali Shan
 */
import java.util.ArrayList;
public class Doctor {
    
    ArrayList<String>patients;
    
    String name;
    String special;
    int exp_year;
    
    Doctor(String n, String sp, int year){
        
        this.name = n;
        this.special = sp;
        this.exp_year = year;
        
        this.patients = new ArrayList<>();
    }
    
    
    void addPatient(String patientName) {
        patients.add(patientName);
    }
    
    void showDoctorInfo() {
        System.out.println("\nDoctor Name: " + name);
        System.out.println("Specialization: " + special);
        System.out.println("Experience Years: " + exp_year);
        System.out.println("Patients: " + patients);
    }
}
