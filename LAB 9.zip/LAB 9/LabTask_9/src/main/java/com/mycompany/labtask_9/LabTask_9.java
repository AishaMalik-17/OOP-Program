/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.labtask_9;

/**
 *
 * @author Ali Shan
 */
public class LabTask_9 {
    public static void main(String[] args) {
     
        Doctor doctor1 = new Doctor("Dr. Ayesha", "Cardiology", 10);
        Doctor doctor2 = new Doctor("Dr. Sadia", "ENT", 15);
        
        doctor1.addPatient("Zaara");
        doctor1.addPatient("Saara");
        doctor2.addPatient("Laila");

        
        Hospital hospital = new Hospital("Shifa Hoaspital", "Islamabad");
        
        hospital.addDoctor(doctor1);
        hospital.addDoctor(doctor2);
        
        hospital.display();
     
    }

    }

